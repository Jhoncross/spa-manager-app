const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Conexión a MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'spa_manager'
});

// Verificar conexión
db.connect((err) => {
    if (err) {
        console.error('❌ Error conectando a MySQL:', err);
        return;
    }
    console.log('✅ Conectado a MySQL - Base de datos: spa_manager');
});

// RUTAS DE LA API

// GET - Obtener todas las citas
app.get('/api/citas', (req, res) => {
    const sql = `
        SELECT c.*, s.nombre as servicio_nombre 
        FROM citas c 
        LEFT JOIN servicios s ON c.servicio_id = s.id
        ORDER BY c.fecha DESC, c.hora DESC
    `;
    
    db.query(sql, (err, results) => {
        if (err) {
            console.error('❌ Error en GET /api/citas:', err);
            return res.status(500).json({ error: 'Error del servidor' });
        }
        console.log('📋 Citas obtenidas:', results.length);
        res.json(results);
    });
});

// POST - Crear nueva cita
app.post('/api/citas', (req, res) => {
    const { nombre_cliente, servicio_id, fecha, hora, estado } = req.body;
    
    console.log('📝 Creando cita:', { nombre_cliente, servicio_id, fecha, hora, estado });

    // Validaciones
    if (!nombre_cliente || !servicio_id || !fecha || !hora) {
        return res.status(400).json({ error: 'Faltan campos obligatorios' });
    }

    const sql = `
        INSERT INTO citas (nombre_cliente, servicio_id, fecha, hora, estado) 
        VALUES (?, ?, ?, ?, ?)
    `;
    
    db.query(sql, [nombre_cliente, servicio_id, fecha, hora, estado || 'pendiente'], 
        (err, results) => {
            if (err) {
                console.error('❌ Error en POST /api/citas:', err);
                return res.status(500).json({ error: 'Error creando cita' });
            }
            console.log('✅ Cita creada - ID:', results.insertId);
            res.json({ 
                success: true, 
                message: 'Cita creada exitosamente',
                id: results.insertId 
            });
        }
    );
});

// PUT - Actualizar cita
app.put('/api/citas/:id', (req, res) => {
    const { id } = req.params;
    const { nombre_cliente, servicio_id, fecha, hora, estado } = req.body;
    
    console.log('✏️ Actualizando cita ID:', id);

    const sql = `
        UPDATE citas 
        SET nombre_cliente = ?, servicio_id = ?, fecha = ?, hora = ?, estado = ?
        WHERE id = ?
    `;
    
    db.query(sql, [nombre_cliente, servicio_id, fecha, hora, estado, id], 
        (err, results) => {
            if (err) {
                console.error('❌ Error en PUT /api/citas:', err);
                return res.status(500).json({ error: 'Error actualizando cita' });
            }
            console.log('✅ Cita actualizada - ID:', id);
            res.json({ success: true, message: 'Cita actualizada exitosamente' });
        }
    );
});

// DELETE - Eliminar cita
app.delete('/api/citas/:id', (req, res) => {
    const { id } = req.params;
    
    console.log('🗑️ Eliminando cita ID:', id);

    const sql = 'DELETE FROM citas WHERE id = ?';
    
    db.query(sql, [id], (err, results) => {
        if (err) {
            console.error('❌ Error en DELETE /api/citas:', err);
            return res.status(500).json({ error: 'Error eliminando cita' });
        }
        console.log('✅ Cita eliminada - ID:', id);
        res.json({ success: true, message: 'Cita eliminada exitosamente' });
    });
});

// GET - Obtener servicios
app.get('/api/servicios', (req, res) => {
    const sql = 'SELECT * FROM servicios';
    
    db.query(sql, (err, results) => {
        if (err) {
            console.error('❌ Error en GET /api/servicios:', err);
            return res.status(500).json({ error: 'Error del servidor' });
        }
        console.log('📦 Servicios obtenidos:', results.length);
        res.json(results);
    });
});

// Ruta de prueba
app.get('/', (req, res) => {
    res.json({ 
        message: '🚀 API REST SPA Manager funcionando!',
        endpoints: {
            citas: {
                GET: '/api/citas',
                POST: '/api/citas',
                PUT: '/api/citas/:id', 
                DELETE: '/api/citas/:id'
            },
            servicios: {
                GET: '/api/servicios'
            }
        }
    });
});

// Iniciar servidor
app.listen(PORT, () => {
    console.log(`🚀 API REST corriendo en: http://localhost:${PORT}`);
    console.log(`📊 Endpoints disponibles:`);
    console.log(`   GET    http://localhost:${PORT}/api/citas`);
    console.log(`   POST   http://localhost:${PORT}/api/citas`);
    console.log(`   PUT    http://localhost:${PORT}/api/citas/:id`);
    console.log(`   DELETE http://localhost:${PORT}/api/citas/:id`);
    console.log(`   GET    http://localhost:${PORT}/api/servicios`);
    console.log(`   TEST   http://localhost:${PORT}/`);
});