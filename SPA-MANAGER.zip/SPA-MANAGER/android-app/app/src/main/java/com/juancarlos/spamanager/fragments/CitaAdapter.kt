package com.juancarlos.spamanager.fragments

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.juancarlos.spamanager.R
import com.juancarlos.spamanager.model.Cita

class CitaAdapter(
    private var citas: List<Cita>,
    private val onEditClick: (Cita) -> Unit,
    private val onDeleteClick: (Cita) -> Unit
) : RecyclerView.Adapter<CitaAdapter.CitaViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CitaViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_cita, parent, false)
        return CitaViewHolder(view)
    }

    override fun onBindViewHolder(holder: CitaViewHolder, position: Int) {
        val cita = citas[position]
        holder.bind(cita)

        holder.itemView.setOnClickListener {
            onEditClick(cita)
        }

        holder.itemView.setOnLongClickListener {
            onDeleteClick(cita)
            true
        }
    }

    override fun getItemCount(): Int = citas.size

    fun updateCitas(newCitas: List<Cita>) {
        citas = newCitas
        notifyDataSetChanged()
    }

    class CitaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val txtCliente: TextView = itemView.findViewById(R.id.txtCliente)
        private val txtServicio: TextView = itemView.findViewById(R.id.txtServicio)
        private val txtFechaHora: TextView = itemView.findViewById(R.id.txtFechaHora)
        private val txtEstado: TextView = itemView.findViewById(R.id.txtEstado)

        fun bind(cita: Cita) {
            txtCliente.text = cita.nombre_cliente
            txtServicio.text = cita.servicio_nombre ?: "Servicio ${cita.servicio_id}"
            txtFechaHora.text = "${cita.fecha} - ${cita.hora}"
            txtEstado.text = cita.estado
        }
    }
}