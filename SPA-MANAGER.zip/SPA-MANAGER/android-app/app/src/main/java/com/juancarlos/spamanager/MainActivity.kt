package com.juancarlos.spamanager

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.juancarlos.spamanager.fragments.CitaListFragment

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Log.e("🔥", "✅ MainActivity - onCreate INICIADO")

        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        Log.e("🔥", "✅ Layout cargado - Buscando fragment_container")

        // SOLUCIÓN: Configurar EdgeToEdge DESPUÉS de asegurar que la vista existe
        val mainContainer = findViewById<View>(android.R.id.content)
        ViewCompat.setOnApplyWindowInsetsListener(mainContainer) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            Log.e("🔥", "✅ EdgeToEdge configurado")
            insets
        }

        // Verificar que el fragment_container existe
        val fragmentContainer = findViewById<View>(R.id.fragment_container)
        if (fragmentContainer == null) {
            Log.e("🔥", "❌ ERROR: fragment_container NO ENCONTRADO!")
            return
        } else {
            Log.e("🔥", "✅ fragment_container encontrado - ID: ${fragmentContainer.id}")
        }

        // Cargar el fragment inicial (Lista de Citas)
        if (savedInstanceState == null) {
            Log.e("🔥", "🔄 Cargando CitaListFragment...")
            replaceFragment(CitaListFragment())
        }
    }

    private fun replaceFragment(fragment: Fragment) {
        Log.e("🔥", "✅ Iniciando transacción del Fragment")

        try {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit()
            Log.e("🔥", "✅ Fragment cargado en pantalla!")
        } catch (e: Exception) {
            Log.e("🔥", "❌ ERROR cargando fragment: ${e.message}")
            e.printStackTrace()
        }
    }
}