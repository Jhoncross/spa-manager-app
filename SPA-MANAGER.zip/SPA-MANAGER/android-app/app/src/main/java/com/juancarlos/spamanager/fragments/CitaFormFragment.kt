package com.juancarlos.spamanager.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.google.android.material.textfield.TextInputEditText
import com.juancarlos.spamanager.R
import com.juancarlos.spamanager.model.Cita
import com.juancarlos.spamanager.model.Servicio
import com.juancarlos.spamanager.service.ApiService
import com.juancarlos.spamanager.service.RetrofitClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class CitaFormFragment : Fragment() {

    private lateinit var apiService: ApiService
    private var serviciosList: List<Servicio> = emptyList()

    // Referencias a las vistas
    private lateinit var editTextNombreCliente: TextInputEditText
    private lateinit var spinnerServicios: Spinner
    private lateinit var editTextFecha: EditText
    private lateinit var editTextHora: EditText
    private lateinit var btnGuardarCita: Button
    private lateinit var btnCancelar: Button
    private lateinit var progressBar: ProgressBar

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_cita_form, container, false)

        // Enlazar vistas manualmente
        editTextNombreCliente = view.findViewById(R.id.editTextNombreCliente)
        spinnerServicios = view.findViewById(R.id.spinnerServicios)
        editTextFecha = view.findViewById(R.id.editTextFecha)
        editTextHora = view.findViewById(R.id.editTextHora)
        btnGuardarCita = view.findViewById(R.id.btnGuardarCita)
        btnCancelar = view.findViewById(R.id.btnCancelar)
        progressBar = view.findViewById(R.id.progressBar)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        apiService = RetrofitClient.instance.create(ApiService::class.java)

        setupUI()
        loadServicios()
        setupClickListeners()

        // VERIFICAR SI ES EDICIÓN - NUEVO CÓDIGO
        verificarModoEdicion()
    }

    private fun setupUI() {
        // Configurar fecha mínima como hoy
        val calendar = Calendar.getInstance()
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        editTextFecha.setText(dateFormat.format(calendar.time))

        // Configurar hora por defecto
        editTextHora.setText("10:00")
    }

    private fun verificarModoEdicion() {
        // Verificar si es edición
        arguments?.let { bundle ->
            val citaId = bundle.getInt("cita_id", -1)
            val modoEdicion = citaId != -1

            if (modoEdicion) {
                // Llenar formulario con datos existentes
                editTextNombreCliente.setText(bundle.getString("nombre_cliente", ""))
                editTextFecha.setText(bundle.getString("fecha", ""))
                editTextHora.setText(bundle.getString("hora", ""))

                // Cambiar texto del botón
                btnGuardarCita.text = "Actualizar Cita"

                Log.e("🔥", "Modo edición - Cita ID: $citaId")
            }
        }
    }

    private fun loadServicios() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = apiService.getServicios()
                if (response.isSuccessful) {
                    serviciosList = response.body() ?: emptyList()

                    // Actualizar UI en el hilo principal
                    activity?.runOnUiThread {
                        setupServiciosSpinner()
                    }
                }
            } catch (e: Exception) {
                Log.e("CitaForm", "Error cargando servicios: ${e.message}")
            }
        }
    }

    private fun setupServiciosSpinner() {
        val serviciosNombres = serviciosList.map { it.nombre }
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, serviciosNombres)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerServicios.adapter = adapter
    }

    private fun setupClickListeners() {
        btnGuardarCita.setOnClickListener {
            guardarCita()
        }

        btnCancelar.setOnClickListener {
            // Regresar a la lista
            activity?.supportFragmentManager?.popBackStack()
        }
    }

    private fun guardarCita() {
        val nombreCliente = editTextNombreCliente.text.toString().trim()
        val fecha = editTextFecha.text.toString().trim()
        val hora = editTextHora.text.toString().trim()

        if (nombreCliente.isEmpty() || fecha.isEmpty() || hora.isEmpty()) {
            Toast.makeText(requireContext(), "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show()
            return
        }

        val servicioSeleccionadoPos = spinnerServicios.selectedItemPosition
        if (servicioSeleccionadoPos == -1) {
            Toast.makeText(requireContext(), "Selecciona un servicio", Toast.LENGTH_SHORT).show()
            return
        }

        val servicioSeleccionado = serviciosList[servicioSeleccionadoPos]

        // Verificar si es edición - NUEVO CÓDIGO
        val modoEdicion = arguments?.getInt("cita_id", -1) ?: -1 != -1
        val citaId = arguments?.getInt("cita_id", -1) ?: -1

        val nuevaCita = Cita(
            id = if (modoEdicion) citaId else null,
            nombre_cliente = nombreCliente,
            servicio_id = servicioSeleccionado.id,
            fecha = fecha,
            hora = hora,
            estado = arguments?.getString("estado") ?: "pendiente"
        )

        progressBar.visibility = View.VISIBLE
        btnGuardarCita.isEnabled = false

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = if (modoEdicion) {
                    apiService.updateCita(citaId, nuevaCita)
                } else {
                    apiService.createCita(nuevaCita)
                }

                activity?.runOnUiThread {
                    progressBar.visibility = View.GONE
                    btnGuardarCita.isEnabled = true

                    if (response.isSuccessful) {
                        val mensaje = if (modoEdicion) "✅ Cita actualizada" else "✅ Cita creada"
                        Toast.makeText(requireContext(), mensaje, Toast.LENGTH_SHORT).show()
                        activity?.supportFragmentManager?.popBackStack()
                    } else {
                        Toast.makeText(requireContext(), "❌ Error", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                activity?.runOnUiThread {
                    progressBar.visibility = View.GONE
                    btnGuardarCita.isEnabled = true
                    Toast.makeText(requireContext(), "❌ Error de conexión", Toast.LENGTH_SHORT).show()
                    Log.e("CitaForm", "Error: ${e.message}")
                }
            }
        }
    }
}