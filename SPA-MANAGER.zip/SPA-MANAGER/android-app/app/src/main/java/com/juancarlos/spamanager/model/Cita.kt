package com.juancarlos.spamanager.model

data class Cita(
    val id: Int? = null,
    val nombre_cliente: String,
    val servicio_id: Int,
    val fecha: String,
    val hora: String,
    val estado: String = "pendiente",
    val servicio_nombre: String? = null
)