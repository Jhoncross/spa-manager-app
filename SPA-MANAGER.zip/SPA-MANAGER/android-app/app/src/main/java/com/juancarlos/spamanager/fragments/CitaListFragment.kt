package com.juancarlos.spamanager.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.juancarlos.spamanager.R
import com.juancarlos.spamanager.model.Cita
import com.juancarlos.spamanager.service.ApiService
import com.juancarlos.spamanager.service.RetrofitClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CitaListFragment : Fragment() {

    private lateinit var apiService: ApiService
    private lateinit var adapter: CitaAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.e("🔥", "✅ CitaListFragment - onCreate")
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        Log.e("🔥", "✅ CitaListFragment - onCreateView")
        val view = inflater.inflate(R.layout.fragment_cita_list, container, false)
        Log.e("🔥", "✅ View inflada: ${view != null}")
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Log.e("🔥", "✅ CitaListFragment - onViewCreated")

        // Inicializar vistas
        recyclerView = view.findViewById(R.id.recyclerViewCitas)
        progressBar = view.findViewById(R.id.progressBar)

        // Configurar RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        // Inicializar adapter
        adapter = CitaAdapter(
            citas = emptyList(),
            onEditClick = { cita ->
                abrirEditarCita(cita)
            },
            onDeleteClick = { cita ->
                mostrarDialogoEliminar(cita)
            }
        )
        recyclerView.adapter = adapter

        // Inicializar Retrofit
        apiService = RetrofitClient.instance.create(ApiService::class.java)

        setupFloatingActionButton()
        cargarCitas()
    }

    private fun setupFloatingActionButton() {
        view?.findViewById<FloatingActionButton>(R.id.fabAgregarCita)?.setOnClickListener {
            Log.e("🔥", "➕ Botón flotante clickeado - Abriendo formulario")

            // Navegar al formulario de nueva cita
            val fragmentManager = requireActivity().supportFragmentManager
            fragmentManager.beginTransaction()
                .replace(R.id.fragment_container, CitaFormFragment())
                .addToBackStack(null)
                .commit()
        }
    }

    private fun cargarCitas() {
        progressBar.visibility = View.VISIBLE

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = apiService.getCitas()
                activity?.runOnUiThread {
                    progressBar.visibility = View.GONE

                    if (response.isSuccessful) {
                        val citas = response.body() ?: emptyList()
                        adapter.updateCitas(citas)
                        Log.e("🔥", "Citas cargadas: ${citas.size}")
                    } else {
                        Toast.makeText(requireContext(), "Error cargando citas", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                activity?.runOnUiThread {
                    progressBar.visibility = View.GONE
                    Toast.makeText(requireContext(), "Error de conexión", Toast.LENGTH_SHORT).show()
                    Log.e("🔥", "Error: ${e.message}")
                }
            }
        }
    }

    private fun abrirEditarCita(cita: Cita) {
        Log.e("🔥", "Editando cita: ${cita.id} - ${cita.nombre_cliente}")

        val fragment = CitaFormFragment().apply {
            arguments = Bundle().apply {
                putInt("cita_id", cita.id ?: -1)
                putString("nombre_cliente", cita.nombre_cliente)
                putInt("servicio_id", cita.servicio_id)
                putString("fecha", cita.fecha)
                putString("hora", cita.hora)
                putString("estado", cita.estado)
            }
        }

        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .addToBackStack(null)
            .commit()
    }

    private fun mostrarDialogoEliminar(cita: Cita) {
        AlertDialog.Builder(requireContext())
            .setTitle("Eliminar Cita")
            .setMessage("¿Estás seguro de eliminar la cita de ${cita.nombre_cliente}?")
            .setPositiveButton("Eliminar") { dialog, which ->
                eliminarCita(cita.id ?: -1)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun eliminarCita(id: Int) {
        progressBar.visibility = View.VISIBLE

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = apiService.deleteCita(id)
                activity?.runOnUiThread {
                    progressBar.visibility = View.GONE

                    if (response.isSuccessful) {
                        Toast.makeText(requireContext(), "Cita eliminada", Toast.LENGTH_SHORT).show()
                        cargarCitas() // Recargar lista
                    } else {
                        Toast.makeText(requireContext(), "Error eliminando cita", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                activity?.runOnUiThread {
                    progressBar.visibility = View.GONE
                    Toast.makeText(requireContext(), "Error de conexión", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}