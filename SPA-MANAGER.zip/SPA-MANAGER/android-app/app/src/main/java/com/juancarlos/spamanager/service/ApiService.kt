package com.juancarlos.spamanager.service

import com.juancarlos.spamanager.model.ApiResponse
import com.juancarlos.spamanager.model.Cita
import com.juancarlos.spamanager.model.Servicio
import retrofit2.Response
import retrofit2.http.*

interface ApiService {
    @GET("api/citas")
    suspend fun getCitas(): Response<List<Cita>>

    @POST("api/citas")
    suspend fun createCita(@Body cita: Cita): Response<ApiResponse>

    @PUT("api/citas/{id}")
    suspend fun updateCita(@Path("id") id: Int, @Body cita: Cita): Response<ApiResponse>

    @DELETE("api/citas/{id}")
    suspend fun deleteCita(@Path("id") id: Int): Response<ApiResponse>

    @GET("api/servicios")
    suspend fun getServicios(): Response<List<Servicio>>
}