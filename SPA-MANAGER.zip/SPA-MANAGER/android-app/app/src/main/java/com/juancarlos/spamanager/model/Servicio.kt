package com.juancarlos.spamanager.model

data class Servicio(
    val id: Int,
    val nombre: String,
    val duracion: Int,
    val precio: Double
)