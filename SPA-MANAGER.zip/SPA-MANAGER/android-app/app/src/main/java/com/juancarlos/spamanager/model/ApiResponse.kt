package com.juancarlos.spamanager.model

data class ApiResponse(
    val success: Boolean,
    val message: String,
    val id: Int? = null
)