# SPA Manager - Sistema de Gestión de Citas

## Descripción
Aplicación móvil desarrollada con patrón MVC para la gestión de citas en un SPA.

## Estructura del Proyecto
- `/backend` - API REST con Node.js, Express y MySQL
- `/android-app` - Aplicación Android con Kotlin y Retrofit

## Tecnologías
- Frontend: Android Studio, Kotlin, RecyclerView, Retrofit
- Backend: Node.js, Express, MySQL
- Arquitectura: MVC (Modelo-Vista-Controlador)

## Funcionalidades
- CRUD completo de citas (Crear, Leer, Actualizar, Eliminar)
- Conexión a base de datos MySQL
- API REST personalizada
- Interfaz móvil responsiva

## Desarrollado por
[Tu Nombre]